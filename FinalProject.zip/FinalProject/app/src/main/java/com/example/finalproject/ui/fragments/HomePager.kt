package com.example.finalproject.ui.fragments

import com.example.finalproject.ui.fragments.SubHome.SubFragmentHot
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.example.finalproject.ui.fragments.SubHome.SubFragmentNews

class HomePagerAdapter(fragmentActivity: FragmentActivity) : FragmentStateAdapter(fragmentActivity) {

    override fun getItemCount(): Int = 2

    override fun createFragment(position: Int): Fragment {
        return when (position) {
            0 -> SubFragmentHot()
            1 -> SubFragmentNews()
            else -> throw IllegalArgumentException("Invalid position")
        }
    }
}
