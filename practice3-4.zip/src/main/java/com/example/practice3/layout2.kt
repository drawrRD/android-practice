package com.example.practice3

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.practice3.databinding.Layout2Binding

data class WeiXinInfo(val avatar:String, val name:String, val detail :String, val time:String)


private class WeiXin(){
    private val weiXinList = ArrayList<WeiXinInfo>()

    fun addWeiXin(avatar: String, name: String, detail: String, time: String) {
        weiXinList.add(WeiXinInfo(avatar, name, detail, time))
    }

    fun getWeiXinList(): ArrayList<WeiXinInfo> {
        return weiXinList
    }

    fun getListDataStr():String {
        val builder = StringBuilder()
        for (elem in weiXinList) {
            builder.append(elem.toString()).append("\n")
        }
        return builder.toString()
    }
}


private class ViewHolder2(view: View) : RecyclerView.ViewHolder(view){
    val avatar: ImageView = view.findViewById(R.id.avatar)
    val name: TextView = view.findViewById(R.id.name)
    val detail: TextView = view.findViewById(R.id.detail)
    val time: TextView = view.findViewById(R.id.time)
}

private class WeiXinAdapter(val weiXinList: ArrayList<WeiXinInfo>, context: Context) : RecyclerView.Adapter<ViewHolder2>() {

    val context = context
    override fun getItemCount(): Int {
        return weiXinList.size
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder2 {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.weixin, parent, false)
        return ViewHolder2(view)
    }

    override fun onBindViewHolder(holder: ViewHolder2, position: Int) {
        val weiXinInfo = weiXinList[position]
        holder.avatar.setImageResource(context.resources.getIdentifier(weiXinInfo.avatar, "drawable", context.packageName))

        holder.name.text = weiXinInfo.name
        holder.detail.text = weiXinInfo.detail
        holder.time.text = weiXinInfo.time
    }
}


fun layout2(binding: Layout2Binding, context: Context){
    val weixin = WeiXin()
    weixin.addWeiXin("cs", "文件传输助手", "[图片]", "09:06")
    weixin.addWeiXin("scr", "订阅号", "特大暴雨！台风'普拉桑'奔向浙江...", "08:53")
    weixin.addWeiXin("zj", "浙江农林大学后勤服务中心", "网络安全周 | 关注网络安全", "9月14日")


    val trainRecyclerView = binding.wxRecyclerView
    // 布局管理器
    val layoutManager = LinearLayoutManager(context)
    trainRecyclerView.layoutManager = layoutManager
    // 设置适配器
    val adapter = WeiXinAdapter(weixin.getWeiXinList(), context)
    trainRecyclerView.adapter = adapter

}