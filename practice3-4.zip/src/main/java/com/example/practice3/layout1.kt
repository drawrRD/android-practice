package com.example.practice3

import android.content.Context
import android.graphics.Typeface
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.activity.result.ActivityResultLauncher
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.practice3.databinding.Layout1Binding
import java.io.Serializable

data class TrainInfo(val id: Int, val name: String,
                     val station1: String,val station2: String,
                     val time1: String,val time2: String, val takes: String,
                     val best: Int, val first: Int, val second: Int, val least: Int):Serializable


class Train(){
    private val trainList = ArrayList<TrainInfo>()

    fun addTrain(id: Int, name: String, station1: String, station2: String,
                        time1: String, time2: String, takes: String,
                        best: Int, first: Int, second: Int, least: Int) {
        trainList.add(TrainInfo(id, name, station1, station2, time1, time2, takes, best, first, second, least))
    }

    fun getTrainList(): ArrayList<TrainInfo> {
        return trainList
    }

    fun getListDataStr():String{
        val builder = StringBuilder()
        for (elem in trainList){
            builder.append(elem.toString()).append("\n")
        }
        return builder.toString()
    }

    // 根据 id 查找并更新 trainInfo
    fun updateTrainInfo(updatedTrainInfo: TrainInfo) {
        val index = trainList.indexOfFirst { it.id == updatedTrainInfo.id }
        if (index != -1) {
            trainList[index] = updatedTrainInfo
        }
    }
}

fun init(train: Train)
{
    train.addTrain(0, "G1869", "合肥", "杭州", "11:06", "13:26", "2小时20分", 100, 10, 3, 0)
    train.addTrain(1, "G7372", "合肥", "杭州", "06:21", "07:48", "2小时27分", 20, 13, 31, 0)
    train.addTrain(2, "K1039", "合肥", "杭州", "19:11", "23:51", "4小时40分", 0, 6, 100, 15)
    train.addTrain(3, "K733", "合肥", "杭州", "18:21", "22:51", "4小时40分", 0, 6, 100, 15)
}


// view holder
class ViewHolder(view: View) : RecyclerView.ViewHolder(view){
    val name: TextView = view.findViewById(R.id.name)
    val station1: TextView = view.findViewById(R.id.station1)
    val station2: TextView = view.findViewById(R.id.station2)
    val time1: TextView = view.findViewById(R.id.time1)
    val time2: TextView = view.findViewById(R.id.time2)
    val takes: TextView = view.findViewById(R.id.takes)
    val best: TextView = view.findViewById(R.id.best)
    val first: TextView = view.findViewById(R.id.first)
    val second: TextView = view.findViewById(R.id.second)
    val least: TextView = view.findViewById(R.id.least)
}

class TrainAdapter(val trainList: ArrayList<TrainInfo>, val context: Context, private val resultContract: ActivityResultLauncher<TrainInfo>) : RecyclerView.Adapter<ViewHolder>() {
    override fun getItemCount(): Int {
        return trainList.size
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.train, parent, false)
        val holder = ViewHolder(view)
        return holder
    }


    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val trainInfo = trainList[position]

        holder.itemView.setOnClickListener {
            resultContract.launch(trainInfo)
        }

        holder.name.text = trainInfo.name
        holder.station1.text = trainInfo.station1
        holder.station2.text = trainInfo.station2
        holder.time1.text = trainInfo.time1
        holder.time2.text = trainInfo.time2
        holder.takes.text = trainInfo.takes
        holder.best.text = "商务:" + trainInfo.best.toString()
        holder.first.text = "一等:" +trainInfo.first.toString()
        holder.second.text = "二等:" +trainInfo.second.toString()
        holder.least.text = "无座:" +trainInfo.least.toString()

        if (trainInfo.best == 0)
            holder.best.text = "商务:无"
        else if(trainInfo.best > 50){
            holder.best.text = "商务:有票"
            holder.best.typeface = Typeface.DEFAULT_BOLD
        }
        else
            holder.best.typeface = Typeface.DEFAULT_BOLD

        if (trainInfo.first == 0)
            holder.first.text = "一等:无"
        else if(trainInfo.first > 50){
            holder.first.text = "一等:有票"
            holder.first.typeface = Typeface.DEFAULT_BOLD
        }
        else
            holder.first.typeface = Typeface.DEFAULT_BOLD

        if (trainInfo.second == 0)
            holder.second.text = "二等:无"
        else if(trainInfo.second > 50){
            holder.second.text = "二等:有票"
            holder.second.typeface = Typeface.DEFAULT_BOLD
        }
        else
            holder.second.typeface = Typeface.DEFAULT_BOLD

        if (trainInfo.least == 0)
            holder.least.text = "无座:无"
        else if(trainInfo.least > 50){
            holder.least.text = "无座:有票"
            holder.least.typeface = Typeface.DEFAULT_BOLD
        }
        else
            holder.least.typeface = Typeface.DEFAULT_BOLD
    }
}



