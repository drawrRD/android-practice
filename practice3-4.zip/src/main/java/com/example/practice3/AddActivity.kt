package com.example.practice3

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.practice3.databinding.AddTrainBinding

class AddActivity : AppCompatActivity() {
    private lateinit var binding: AddTrainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = AddTrainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val id = intent.getIntExtra("id", 100)


        binding.back.setOnClickListener{
            val intent = Intent()
            setResult(RESULT_CANCELED, intent)
            finish()
        }

        binding.confirm.setOnClickListener{
            val intent = Intent()
            val addTrain = TrainInfo(id, binding.train.text.toString(), binding.start.text.toString(), binding.arrive.text.toString(), binding.time1.text.toString(), binding.time2.text.toString(), binding.takes.text.toString(), binding.business.text.toString().toInt(), binding.first.text.toString().toInt(), binding.second.text.toString().toInt(), binding.no.text.toString().toInt())
            intent.putExtra("trainInfo", addTrain)
            setResult(RESULT_OK, intent)
            finish()
        }
    }
}