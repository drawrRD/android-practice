package com.example.practice3

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.practice3.databinding.Layout1Binding
import com.example.practice3.ui.theme.Practice3Theme

class MainActivity : ComponentActivity() {

    private lateinit var binding: Layout1Binding

    private val train = Train()

    //注册协议，获取启动器
    private val resultContract = registerForActivityResult(
        TrainActivityResultContract()){
            result -> // result为回调函数的返回值
            Toast.makeText(applicationContext,"$result", Toast.LENGTH_SHORT).show()
            train.updateTrainInfo(result)
            // 刷新 UI
            binding.trainRecyclerView.adapter?.notifyDataSetChanged()
    }
    private val addResultContract = registerForActivityResult(
        AddActivityResultContract()){
            result -> // result为回调函数的返回值
            Toast.makeText(applicationContext,"$result", Toast.LENGTH_SHORT).show()
            if (result.id != -1) {
                train.addTrain(result.id, result.name, result.station1, result.station2, result.time1, result.time2, result.takes, result.best, result.first, result.second, result.least)
            }
            // 刷新 UI
            binding.trainRecyclerView.adapter?.notifyDataSetChanged()
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = Layout1Binding.inflate(layoutInflater)
        setContentView(binding.root)
        // 初始化
        init(train)
        val trainRecyclerView = binding.trainRecyclerView
        // 布局管理器
        val layoutManager = LinearLayoutManager(this)
        trainRecyclerView.layoutManager = layoutManager
        // 设置适配器 (自传入上下文context， 启动器resultContract)
        val adapter = TrainAdapter(train.getTrainList(), this, resultContract)
        trainRecyclerView.adapter = adapter


        binding.add.setOnClickListener {
            val id = train.getTrainList().size + 1
            addResultContract.launch(id)
        }

    }


//    private lateinit var binding2: Layout2Binding
//    override fun onCreate(savedInstanceState: Bundle?) {
//        super.onCreate(savedInstanceState)
//        binding2 = Layout2Binding.inflate(layoutInflater)
//        setContentView(binding2.root)
//
//        layout2(binding2, this)
//    }


}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(
        text = "Hello $name!",
        modifier = modifier
    )
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    Practice3Theme {
        Greeting("Android")
    }
}