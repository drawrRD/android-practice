package com.example.practice3

import android.app.Activity
import android.content.Context
import android.content.Intent
import androidx.activity.result.contract.ActivityResultContract

class TrainActivityResultContract: ActivityResultContract<TrainInfo, TrainInfo>()  {

    override fun createIntent(context: Context, input: TrainInfo): Intent {
        val intent = Intent(context, TrainActivity::class.java)
        intent.putExtra("trainInfo", input)
        return intent
    }

    override fun parseResult(resultCode: Int, intent: Intent?): TrainInfo {
        if (intent == null) {
            return TrainInfo(0, "", "", "", "", "", "", 0, 0, 0, 0)
        }
        val trainInfo = intent.getSerializableExtra("trainInfo") as TrainInfo
        if(resultCode == Activity.RESULT_OK){
            return trainInfo
        }
        else{
            return TrainInfo(0, "", "", "", "", "", "", 0, 0, 0, 0)
        }

    }
}


class AddActivityResultContract: ActivityResultContract<Int, TrainInfo>()  {

    override fun createIntent(context: Context, input: Int): Intent {
        val intent = Intent(context, AddActivity::class.java)
        intent.putExtra("id", input)
        return intent
    }

    override fun parseResult(resultCode: Int, intent: Intent?): TrainInfo {
        if (resultCode == Activity.RESULT_CANCELED)
            return TrainInfo(-1, "", "", "", "", "", "", 0, 0, 0, 0)
        if(resultCode == Activity.RESULT_OK){
            val trainInfo = intent?.getSerializableExtra("trainInfo") as TrainInfo
            return trainInfo
        }
        else{
            return TrainInfo(0, "", "", "", "", "", "", 0, 0, 0, 0)
        }

    }
}