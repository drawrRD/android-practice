package com.example.practice3

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import androidx.appcompat.app.AppCompatActivity
import com.example.practice3.databinding.TrainDetailBinding

class TrainActivity : AppCompatActivity() {

    private lateinit var binding: TrainDetailBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = TrainDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val trainInfo = CommonUtil.getSerializable(this, "trainInfo", TrainInfo::class.java)
        val id = trainInfo.id
        binding.train.text =  Editable.Factory.getInstance().newEditable(trainInfo.name)
        binding.start.text =  Editable.Factory.getInstance().newEditable(trainInfo.station1)
        binding.arrive.text =  Editable.Factory.getInstance().newEditable(trainInfo.station2)
        binding.time1.text =  Editable.Factory.getInstance().newEditable(trainInfo.time1)
        binding.time2.text =  Editable.Factory.getInstance().newEditable(trainInfo.time2)
        binding.takes.text =  Editable.Factory.getInstance().newEditable(trainInfo.takes)
        binding.business.text =  Editable.Factory.getInstance().newEditable(trainInfo.best.toString())
        binding.first.text =  Editable.Factory.getInstance().newEditable(trainInfo.first.toString())
        binding.second.text =  Editable.Factory.getInstance().newEditable(trainInfo.second.toString())
        binding.no.text =  Editable.Factory.getInstance().newEditable(trainInfo.least.toString())


        binding.back.setOnClickListener{
            val intent = Intent()
            intent.putExtra("trainInfo", trainInfo)
            setResult(RESULT_OK, intent)
            finish()
        }


        binding.confirm.setOnClickListener{
            val intent = Intent()
            val changeTrain = TrainInfo(id, binding.train.text.toString(), binding.start.text.toString(), binding.arrive.text.toString(), binding.time1.text.toString(), binding.time2.text.toString(), binding.takes.text.toString(), binding.business.text.toString().toInt(), binding.first.text.toString().toInt(), binding.second.text.toString().toInt(), binding.no.text.toString().toInt())
            intent.putExtra("trainInfo", changeTrain)
            setResult(RESULT_OK, intent)
            finish()
        }



    }
}