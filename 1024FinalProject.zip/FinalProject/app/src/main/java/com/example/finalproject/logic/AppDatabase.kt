package com.example.finalproject.logic

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.finalproject.logic.dao.NewsDao
import com.example.finalproject.logic.model.News

@Database(entities = [News::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun newsDao(): NewsDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "app_database"
                )
                    .allowMainThreadQueries()   // 允许在主线程中执行数据库操作，仅用于测试
                    .fallbackToDestructiveMigration() // 摧毁数据库以重建，仅用于测试
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }

}