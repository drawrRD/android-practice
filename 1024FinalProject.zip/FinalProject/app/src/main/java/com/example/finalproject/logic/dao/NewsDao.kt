package com.example.finalproject.logic.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.example.finalproject.logic.model.News

@Dao
interface NewsDao {
    @Insert
    fun insert(news: News): Long

    @Delete
    fun delete(news: News)

    @Update
    fun update(newNews: News)

    @Query("select * from news")
    fun loadAllNews(): List<News>
}