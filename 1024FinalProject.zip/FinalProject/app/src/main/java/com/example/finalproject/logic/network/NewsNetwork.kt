package com.example.finalproject.logic.network

import android.util.Log
import android.widget.Toast
import com.example.finalproject.logic.model.News
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL


const val baseURL = "http://10.0.2.2:8000/"



data class NewsApiResponse(
    val code: Int,
    val msg: String,
    val data: List<News>?
)

data class SingleNewsApiResponse(
    val code: Int,
    val msg: String,
    val data: News?
)

fun fetchAllNews(): List<News>? {
    val url = URL(baseURL + "api/news/")
    try {
        val connection = url.openConnection() as HttpURLConnection
        connection.requestMethod = "GET"
        connection.setRequestProperty("Content-Type", "application/json; utf-8")
        connection.setRequestProperty("Accept", "application/json")
        connection.readTimeout = 1000
        connection.connectTimeout = 1000

        val responseCode = connection.responseCode
        val inputStream = connection.inputStream
        val response = inputStream.bufferedReader().use { it.readText() }
        val responseType = object : TypeToken<NewsApiResponse>() {}.type
        val apiResponse = Gson().fromJson<NewsApiResponse>(response, responseType)
        if (responseCode == HttpURLConnection.HTTP_OK) {
            return apiResponse.data ?: emptyList()
        } else {
            Log.d("fetchAllNews", "HTTP error: $apiResponse")
            return null
        }
    }
    catch (e: Exception) {
        Log.d("fetchAllNews", "Network error: $e")
        return null
    }
}

fun fetchNextPageOfNews(page: Int): List<News>? {
    val url = URL(baseURL + "api/news/page/$page/")
    try {
        val connection = url.openConnection() as HttpURLConnection
        connection.requestMethod = "GET"
        connection.setRequestProperty("Content-Type", "application/json; utf-8")
        connection.setRequestProperty("Accept", "application/json")
        connection.readTimeout = 1000
        connection.connectTimeout = 1000

        val responseCode = connection.responseCode
        val inputStream = connection.inputStream
        val response = inputStream.bufferedReader().use { it.readText() }
        val responseType = object : TypeToken<NewsApiResponse>() {}.type
        val apiResponse = Gson().fromJson<NewsApiResponse>(response, responseType)
        if (responseCode == HttpURLConnection.HTTP_OK) {
            return apiResponse.data ?: emptyList()
        } else {
            Log.d("fetchNextPageOfNews", "HTTP error: $apiResponse")
            return null
        }
    }
    catch (e: Exception) {
        Log.d("fetchNextPageOfNews", "Network error: $e")
        return null
    }
}

fun addNews(news: News): Boolean {
    val url = URL(baseURL + "api/news/")
    try {
        val connection = url.openConnection() as HttpURLConnection
        connection.requestMethod = "POST"
        connection.setRequestProperty("Content-Type", "application/json; utf-8")
        connection.setRequestProperty("Accept", "application/json")
        connection.doOutput = true
        connection.outputStream.write(Gson().toJson(news).toByteArray())
        connection.outputStream.flush()
        val responseCode = connection.responseCode
        return if (responseCode == HttpURLConnection.HTTP_OK) {
            true
        } else {
            Log.d("addNews", "HTTP error: $responseCode")
            false
        }
    }
    catch (e: Exception) {
        Log.d("addNews", "Network error: $e")
        return false
    }
}

fun fetchNewsById(id: Long): News? {
    val url = URL(baseURL + "api/news/$id/")
    try {
        val connection = url.openConnection() as HttpURLConnection
        connection.requestMethod = "GET"
        connection.setRequestProperty("Content-Type", "application/json; utf-8")
        connection.setRequestProperty("Accept", "application/json")
        connection.readTimeout = 1000
        connection.connectTimeout = 1000

        val responseCode = connection.responseCode
        val inputStream = connection.inputStream
        val response = inputStream.bufferedReader().use { it.readText() }
        val responseType = object : TypeToken<SingleNewsApiResponse>() {}.type
        val apiResponse = Gson().fromJson<SingleNewsApiResponse>(response, responseType)
        return if (responseCode == HttpURLConnection.HTTP_OK) {
            apiResponse.data
        } else {
            Log.d("fetchNewsById", "HTTP error: $apiResponse")
            null
        }
    }
    catch (e: Exception) {
        Log.d("fetchNewsById", "Network error: $e")
        return null
    }
}



fun fetchTest(): String {
    var connection: HttpURLConnection? = null
    return try {
        val response = StringBuilder()
        val url = URL("http://10.0.2.2:8000/api/test/")
        connection = url.openConnection() as HttpURLConnection
        connection.connectTimeout = 1000 // 连接超时
        connection.readTimeout = 1000 // 读取超时
        val input = connection.inputStream
        val reader = BufferedReader(InputStreamReader(input))
        reader.use {
            reader.forEachLine {
                response.append(it)
            }
        }
        response.toString()
    }
    catch (e: Exception){
        e.printStackTrace()
        Log.d("fetchTest", e.message.toString())
        return "网络错误"
    }
    finally {
        connection?.disconnect()
    }
}