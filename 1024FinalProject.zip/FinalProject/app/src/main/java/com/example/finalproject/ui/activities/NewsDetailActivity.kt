package com.example.finalproject.ui.activities

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.PopupMenu
import androidx.appcompat.widget.Toolbar
import androidx.lifecycle.lifecycleScope
import com.example.finalproject.R
import com.example.finalproject.databinding.ActivityNewsDetailBinding
import com.example.finalproject.logic.network.fetchNewsById
import com.google.android.material.bottomsheet.BottomSheetDialog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext


class NewsDetailActivity : AppCompatActivity() {
    private lateinit var binding: ActivityNewsDetailBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityNewsDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // 获取传递过来的新闻对象id
        val id = intent.getLongExtra("id", -1)

        lifecycleScope.launch {
            val news = withContext(Dispatchers.IO) { fetchNewsById(id) }
            if (news == null)
            {
                Toast.makeText(this@NewsDetailActivity, "新闻不存在", Toast.LENGTH_SHORT).show()
                finish()
            }
            else{
                // 显示新闻详情
                binding.newsDetailTitle.text = news.id.toString()
                binding.newsDetailContent.text = news.content
            }
        }

        val toolbar: Toolbar = findViewById(R.id.toolbar1)
        setSupportActionBar(toolbar)

        val backButton = binding.backButton
        backButton.setOnClickListener {
            finish()
        }
        val moreButton = binding.moreButton
        moreButton.setOnClickListener {
            // 创建一个PopupMenu
            val popup = PopupMenu(this, moreButton)
            val inflater = popup.menuInflater
            inflater.inflate(R.menu.news_menu_more, popup.menu)
            // 设置菜单项点击事件
            popup.setOnMenuItemClickListener { item ->
                when (item.itemId) {
                    R.id.news_more_subscribe -> {
                        // 执行设置操作
                        Toast.makeText(this, "订阅成功", Toast.LENGTH_SHORT).show()
                        true
                    }
                    R.id.news_more_share -> {
                        // 执行帮助与反馈操作
                        Toast.makeText(this, "分享成功", Toast.LENGTH_SHORT).show()
                        true
                    }
                    else -> false
                }
            }
            // 显示菜单
            popup.show()
        }
        val commentEdit = binding.commentEdit
        commentEdit.setOnClickListener {
            showCommentInputDialog()
        }

    }

    private fun showCommentInputDialog() {
        val dialog = BottomSheetDialog(this)
        val view = layoutInflater.inflate(R.layout.dialog_comment_input, null)

        val fullCommentEdit = view.findViewById<EditText>(R.id.full_comment_edit)
        val submitButton = view.findViewById<Button>(R.id.submit_button)

        submitButton.setOnClickListener {
            // 获取用户输入的内容
            val comment = fullCommentEdit.text.toString()

            // 处理评论提交逻辑
            // 例如：发送评论到服务器、更新UI等
            // 这里只是一个示例
            if (comment.isNotEmpty()) {
                // 更新主界面的 EditText 内容
                findViewById<EditText>(R.id.comment_edit).setText(comment)
                dialog.dismiss()
            } else {
                fullCommentEdit.error = "评论不能为空"
            }
        }

        dialog.setContentView(view)
        dialog.show()
    }

}