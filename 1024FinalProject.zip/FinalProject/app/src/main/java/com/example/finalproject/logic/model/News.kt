package com.example.finalproject.logic.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.Date


@Entity(tableName = "news")
data class News(
    @PrimaryKey(autoGenerate = true)
    val id: Long ?=null,
    val title: String,
    val content: String,
    val image: String?=null,
    val category: Int?=null,
    val likes: Int?=null,
    val comments: Int?=null,
    val watches: Long?=null,
    val create_time: String?=null,
    val update_time: String?=null,
    val is_recommend: Boolean?=null,
    val author_id: Long?=null
)


