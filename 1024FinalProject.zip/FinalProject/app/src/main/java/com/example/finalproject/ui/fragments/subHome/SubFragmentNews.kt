package com.example.finalproject.ui.fragments.subHome

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.example.finalproject.R
import com.example.finalproject.logic.AppDatabase
import com.example.finalproject.logic.model.News
import com.example.finalproject.logic.network.addNews
import com.example.finalproject.logic.network.fetchAllNews
import com.example.finalproject.logic.network.fetchNextPageOfNews
import com.example.finalproject.logic.network.fetchTest
import com.example.finalproject.ui.fragments.NewsAdapter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class SubFragmentNews : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_sub_news, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // 初始化 RecyclerView
        val recyclerView = view.findViewById<RecyclerView>(R.id.NewsRecyclerView)
        recyclerView.layoutManager = LinearLayoutManager(requireContext())
        val adapter = NewsAdapter()
        recyclerView.adapter = adapter
        // 设置RecyclerView滚动监听器
        recyclerView.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                super.onScrolled(recyclerView, dx, dy)
                val layoutManager = recyclerView.layoutManager as LinearLayoutManager
                val totalItemCount = layoutManager.itemCount
                val lastVisibleItem = layoutManager.findLastVisibleItemPosition()
                // 当最后一个可见项接近底部时触发加载更多
                // 调试输出
                Log.d("ScrollDebug", "Total Items: $totalItemCount, Last Visible Item: $lastVisibleItem, isLoading: $isLoading, isLastPage: $isLastPage")
                if (!isLoading && !isLastPage && totalItemCount - lastVisibleItem - 1 <= visibleThreshold) {
                    loadMoreItems(adapter)
                    isLoading = true
                }
            }
        })
        // 初始化下拉刷新
        val refreshLayout = view.findViewById<SwipeRefreshLayout>(R.id.refreshLayout)
        refreshLayout.setOnRefreshListener {
            lifecycleScope.launch {
                currentPage = 1
                isLastPage = false
                val newsList =  withContext(Dispatchers.IO) { fetchNextPageOfNews(1) }
                if (newsList == null) {
                    refreshLayout.isRefreshing = false
                    Toast.makeText(requireContext(), "网络错误", Toast.LENGTH_SHORT).show()
                }
                else{
                    adapter.submitList(newsList)
                    refreshLayout.isRefreshing = false
                    Toast.makeText(requireContext(), "刷新成功", Toast.LENGTH_SHORT).show()
                }
            }
        }
        // 初始化，加载第一页数据
        lifecycleScope.launch {
            currentPage = 1
            isLastPage = false
            val newsList =  withContext(Dispatchers.IO) { fetchNextPageOfNews(1) }
            adapter.submitList(newsList)
            Toast.makeText(requireContext(), "result: $newsList", Toast.LENGTH_SHORT).show()
        }
        // 增加
        val addButton = view.findViewById<View>(R.id.addButton)
        addButton.setOnClickListener {
            thread {
                val news = News(null, "test", "test", null, null, null, null, null, null, null, null)
                val result = addNews(news)
                if (!result){
                    activity?.runOnUiThread {
                            Toast.makeText(requireContext(), "网络错误", Toast.LENGTH_SHORT).show()
                        }
                }
                else{
                    refreshNews(adapter)
                    activity?.runOnUiThread {
                        Toast.makeText(requireContext(), "result: $result", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
        // 刷新
        val interButton = view.findViewById<View>(R.id.interButton)
        interButton.setOnClickListener {
            thread {
                if (refreshNews(adapter)){
                    activity?.runOnUiThread {
                        Toast.makeText(requireContext(), "刷新成功", Toast.LENGTH_SHORT).show()
                    }
                }
                else{
                    activity?.runOnUiThread {
                        Toast.makeText(requireContext(), "网络错误", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }

    }

    private fun refreshNews(adapter: NewsAdapter):Boolean {
        val newsList = fetchAllNews() ?: return false
        adapter.submitList(newsList)
        return true
    }

    // 加载更多数据的方法
    private var isLoading = false
    private var isLastPage = false
    private var currentPage = 1
    private val visibleThreshold = 0 // 距离最后一个可见项目还有多少个条目时开始加载更多数据
    private fun loadMoreItems(adapter: NewsAdapter) {
        lifecycleScope.launch {
            try {
                val newItems = withContext(Dispatchers.IO) {fetchNextPageOfNews(++currentPage)}
                if (newItems != null) {
                    if (newItems.isEmpty()) {
                        currentPage--
                        isLastPage = true
                    } else {
                        // 将新加载的数据添加到现有数据集中
                        val currentList = ArrayList(adapter.currentList)
                        currentList.addAll(newItems)
                        // 通知适配器数据集已更改
                        adapter.submitList(currentList)
                    }
                }
            } catch (e: Exception) {
                Log.e("LoadMoreError", "Failed to load more items", e)
            } finally {
                isLoading = false
            }
        }
    }


}