package com.example.finalproject.ui.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.viewpager2.widget.ViewPager2
import com.example.finalproject.R
import com.example.finalproject.logic.AppDatabase
import com.example.finalproject.logic.dao.NewsDao
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator

class HomeFragment: Fragment() {

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_home, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // 获取 TabLayout 和 ViewPager2
        val tabLayout: TabLayout = view.findViewById(R.id.home_tab)
        val viewPager: ViewPager2 = view.findViewById(R.id.view_pager)

        // 设置适配器
        val adapter = HomePagerAdapter(requireActivity())
        viewPager.adapter = adapter

        // 将 TabLayout 与 ViewPager2 关联
        TabLayoutMediator(tabLayout, viewPager) { tab, position ->
            when (position) {
                0 -> tab.text = "热门"
                1 -> tab.text = "要闻"
            }
        }.attach()
        viewPager.setCurrentItem(1, false)

    }

}