package com.example.finalproject.ui.fragments

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.bumptech.glide.Glide
import com.example.finalproject.R
import com.example.finalproject.logic.model.News
import com.example.finalproject.logic.network.baseURL
import com.example.finalproject.ui.activities.NewsDetailActivity
import com.example.finalproject.ui.fragments.subHome.SubFragmentHot
import com.example.finalproject.ui.fragments.subHome.SubFragmentNews
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter


class HomePagerAdapter(fragmentActivity: FragmentActivity) : FragmentStateAdapter(fragmentActivity) {

    override fun getItemCount(): Int = 2

    override fun createFragment(position: Int): Fragment {
        return when (position) {
            0 -> SubFragmentHot()
            1 -> SubFragmentNews()
            else -> throw IllegalArgumentException("Invalid position")
        }
    }
}



class NewsAdapter: ListAdapter<News, NewsAdapter.NewsViewHolder>(DiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NewsViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.item_news, parent, false)
        return NewsViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: NewsViewHolder, position: Int) {
        val currentNews = getItem(position)
        holder.bind(currentNews)
    }

    class NewsViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val titleTextView: TextView = itemView.findViewById(R.id.news_title)
        private val timeTextView: TextView = itemView.findViewById(R.id.news_time)
        private val watchesView: TextView = itemView.findViewById(R.id.news_watch)
        private val imageView: ImageView = itemView.findViewById(R.id.news_image)

        fun bind(news: News) {
            titleTextView.text = news.title
            watchesView.text = "浏览量" + news.watches.toString()
            val inputFormatter = DateTimeFormatter.ISO_DATE_TIME
            val outputFormatter = DateTimeFormatter.ofPattern("MM-dd HH:mm")
            val dateTime = LocalDateTime.parse(news.create_time, inputFormatter)
            val formattedDateTime = dateTime.format(outputFormatter)
            timeTextView.text = formattedDateTime
            Glide.with(itemView).load(baseURL + news.image).into(imageView)
            itemView.setOnClickListener {
                // 处理点击事件，启动新闻详情页Activity
                val intent = Intent(itemView.context, NewsDetailActivity::class.java).apply {
                    putExtra("id", news.id)
                }
                itemView.context.startActivity(intent)
                Toast.makeText(itemView.context, "点击了新闻：${news.title}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    class DiffCallback : DiffUtil.ItemCallback<News>() {
        override fun areItemsTheSame(oldItem: News, newItem: News): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: News, newItem: News): Boolean {
            return oldItem == newItem
        }
    }
}
